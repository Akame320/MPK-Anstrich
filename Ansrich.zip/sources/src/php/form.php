<?php

/* https://api.telegram.org/bot1779811522:AAGK8GtXfc6b1Di8RxcBhL-iE89eK7GSzh8/getUpdates,
где, XXXXXXXXXXXXXXXXXXXXXXX - токен вашего бота, полученный ранее */

//Переменная $name,$phone, $mail получает данные при помощи метода POST из формы
$name = $_POST['name'];
$phone = $_POST['tel'];
$email = $_POST['email'];

//в переменную $token нужно вставить токен, который нам прислал @botFather
$token = "1779811522:AAGK8GtXfc6b1Di8RxcBhL-iE89eK7GSzh8";

//нужна вставить chat_id (Как получить chad id, читайте ниже)
$chat_id = "-1001394237347";

echo $name;
//echo $phone;
//echo $email;

//Далее создаем переменную, в которую помещаем PHP массив
$arr = array(
    'Имя пользователя: ' => $name,
    'Телефон: ' => $phone,
    'Email:' => $email
);

//При помощи цикла перебираем массив и помещаем переменную $txt текст из массива $arr
foreach($arr as $key => $value) {
    $txt .= "<b>".$key."</b> ".$value."%0A";
};

//Осуществляется отправка данных в переменной $sendToTelegram
$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");



$to      = 'info@mpk-anstrich.ru, ';
$subject = 'Новая заявка с сайта мпк-анстрич.рф';

$message = "Сообщение с сайта мпк-анстрич.рф" . "\r\n";
$message .= "                                  " . "\r\n";
$message .= "__________________________________" . "\r\n";
$message .= "                                  " . "\r\n";
$message .= "Имя - ";
$message .= $name . "\r\n";
$message .= "Телефон - ";
$message .= $phone . "\r\n";
$message .= "Почта - ";
$message .= $email . "\r\n";


$headers = 'From: info@mpk-anstrich.ru' . "\r\n" .
    'Reply-To: info@mpk-anstrich.ru' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);

?>