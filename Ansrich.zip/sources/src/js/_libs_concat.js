module.exports = [
    "./src/libs/jquery/dist/jquery.min.js",
    "./src/libs/slick-carousel/slick/slick.min.js",
    "./src/libs/jquery.maskedinput.min.js",
    "./src/libs/magnific/jquery.magnific-popup.min.js",
];
