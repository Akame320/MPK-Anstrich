$(function () {

    $('.menu-toggle').on('click', function () {
        $(this).toggleClass('active')
        $('.menu-list').slideToggle(300)
    })

    $(window).on('scroll', function () {
        if ($(window).scrollTop() !== 0) {
            $('.header').addClass('fixed-mode')
        } else {
            $('.header').removeClass('fixed-mode')
        }

    })

    $('.portfolio-section__slider.slider-1').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        prevArrow: $('.slider-arrow.slider-arrow-prev.arrow-prev-slide-1'),
        nextArrow: $('.slider-arrow.slider-arrow-next.arrow-next-slide-1'),
        infinite: true,
        autoplay: true,
        autoplaySpeed: 2000,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }]
    })

    var noneQuestions = $('.questions-section__row.none-visible').length
    $('.out-length-questions').text(noneQuestions);

    $(' .questions-section__btn').on('click', function () {
        $('.questions-section__row.none-visible').slideToggle(300)
        $(this).toggleClass('active')
        $(this).toggleClass('no-active')
    })

    $('.brand-section__slider.slider-2').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        prevArrow: $('.slider-arrow.slider-arrow-prev.arrow-prev-slide-2'),
        nextArrow: $('.slider-arrow.slider-arrow-next.arrow-next-slide-2'),
        autoplay: true,
        autoplaySpeed: 1500,
        responsive: [
            {
                breakpoint: 800,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                }
            }]
    })

    setNavigation();

    function setNavigation() {
        var path = window.location.pathname;
        path = path.replace(/\/$/, "");
        path = decodeURIComponent(path);

        $(".submenu-list a").each(function () {
            var href = $(this).attr('href');
            if (path.indexOf(href) !== -1) {
                $(this).closest('li').addClass('active');
            }
        });
    }

    $('.price-section__row-header').on('click', function () {
        $(this).next().slideToggle(350);
        $(this).toggleClass('active')
    })

    $('.input-tel').mask("+7 (999) 999-99-99", {placeholder: '+7 (xxx) xxx-xx-xx'})


    $('.popup-police-close').on('click', function () {
        $("#popup-police").removeClass('active');
    })

    $('[href="police.html"]').on('click', function (event) {
        event.preventDefault();
        $("#popup-police").addClass('active');
    })

    $('.portfolio-section__slider.slider-1').magnificPopup({
        delegate: 'a', // child items selector, by clicking on it popup will open
        type: 'image'
        // other options
    });

    $('.popup-thanks__close').on('click', function () {
        $('#popup-thanks').removeClass('active title-yes title-no')
    })
})

$(".form-submit").on("submit", function (event) {
    event.preventDefault();

    const form = new FormData($(this)[0]);

    var valid = true;

    var noChars = ["!", "@", "№", "$", ";", "%", "^", ":", "&", "?", "*", "(", ")",
        "_", "-", "+", "=", "<", ">", "'", ",", "/", "|", "]", "[", "{", "}", "`", "~", "'",
        "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "#"];

    if (form.has("tel")) {
        var str = form.get("tel")
        str = str.split("-").join("");
        str = str.split("(").join("");
        str = str.split(")").join("");
        str = str.split("+").join("");
        str = str.split(" ").join("");

        if ((str.length != 11) && (!str)) {
            $(this).find("input[name='tel']").removeClass("yes-valid")
            $(this).find("input[name='tel']").addClass("no-valid");
            valid = false;
        } else {
            $(this).find("input[name='tel']").removeClass("no-valid")
            $(this).find("input[name='tel']").addClass("yes-valid");
        }

    }

    if (form.has("name")) {
        console.log(valid)
        if (!form.get("name")) {
            console.log('sdfsdf')
            $(this).find("input[name='name']").addClass("yes-valid");
        }

        var str = form.get("name").split("");
        console.log(str)
        console.log(noChars)

        for (var i = 0; i < str.length; i++) {
            for (var i1 = 0; i1 < noChars.length; i1++) {
                if (str[i] === noChars[i1]) {
                    $(this).find("input[name='name']").removeClass("yes-valid");
                    $(this).find("input[name='name']").addClass("no-valid");
                    valid = false;
                    return false
                } else {
                    $(this).find("input[name='name']").removeClass("no-valid");
                    $(this).find("input[name='name']").addClass("yes-valid");
                }
            }
        }
    }

    if (form.has("email")) {

        var str = form.get("email");
        console.log(str)

        if (str && str !== " ") {
            if (str.indexOf("@") !== -1) {
                $(this).find("input[name='email']").removeClass("no-valid");
                $(this).find("input[name='email']").addClass("yes-valid");
            } else {
                $(this).find("input[name='email']").removeClass("yes-valid");
                $(this).find("input[name='email']").addClass("no-valid");
            }
        } else {
            $(this).find("input[name='email']").removeClass("no-valid");
            $(this).find("input[name='email']").addClass("yes-valid");
        }

    }

    console.log(valid)

    if (valid) {
        var getForm = $(this).attr("data-form");
        form.append("Форма", getForm);

        const xml = new XMLHttpRequest();
        xml.open("POST", "../php/form.php");
        xml.send(form);

        xml.onload = () => {
            if (xml.status != 200) {
                $('#popup-thanks').addClass('active title-no')
            } else {
                $('#popup-thanks').addClass('active title-yes')
                $(this).find("input[type='text']").val("")
            }
        }

    }
});

$("input.input-text").on("click", function () {
    $(this).removeClass("no-valid")
    $(this).removeClass("yes-valid")
})


// setTimeout(function () {
//     var elem = document.createElement('script');
//     elem.type = 'text/javascript';
//     elem.src = '//api-maps.yandex.ru/2.1/?load=package.standard&lang=ru-RU&onload=getYaMap';
//     document.getElementsByTagName('body')[0].appendChild(elem);
// }, 2000);
//
// function getYaMap() {
//     var myMap = new ymaps.Map("map", {center: [58.577011, 49.589752], zoom: 15});
//     myGeoObject = new ymaps.GeoObject({
//         geometry: {
//             type: "Point",
//             coordinates: [58.579151, 49.607656]
//         },
//     }, {
//         preset: 'islands#blackStretchyIcon',
//
//         draggable: true
//     })
//     myMap.geoObjects
//         .add(myGeoObject)
//         .add(new ymaps.Placemark([58.579151, 49.607656], {
//             iconCaption: 'МПК-Анстрич офис',
//         }, {
//             preset: 'islands#greenDotIconWithCaption',
//             iconColor: '#84aaff'
//         }))
//
//         .add(new ymaps.Placemark([58.575613, 49.574975], {
//             iconCaption: 'МПК-Анстрич производство',
//         }, {
//             preset: 'islands#greenDotIconWithCaption',
//             iconColor: '#84aaff'
//         }))
// }


setTimeout(function () {
    var elem = document.createElement('script');
    elem.type = 'text/javascript';
    elem.src = '//api-maps.yandex.ru/2.1/?load=package.standard&lang=ru-RU&onload=getYaMap';
    document.getElementsByTagName('body')[0].appendChild(elem);
}, 2000);

function getYaMap() {
    var myMap = new ymaps.Map("map", {center: [43.241885, 76.877508], zoom: 15});
    myGeoObject = new ymaps.GeoObject({
        geometry: {
            type: "Point",
            coordinates: [43.241885, 76.877508]
        },
    }, {
        preset: 'islands#blackStretchyIcon',

        draggable: true
    })
    myMap.geoObjects
        .add(myGeoObject)
        .add(new ymaps.Placemark([43.241885, 76.877508], {
            iconCaption: 'Delux - сервис центр',
        }, {
            preset: 'islands#greenDotIconWithCaption',
            iconColor: '#84aaff'
        }))
}