<?php

$link = mysqli_connect("localhost", "akame320_mito", "hidizo33", "akame320_mito");
mysqli_set_charset($link, "utf8");

if ($link == false) {

    print("Ошибка: Невозможно подключиться к MySQL " . mysqli_connect_error());

} else {

    print("Соединение установлено успешно <br>");

    $query1 = mysqli_query($link, "SELECT * FROM cites");

    // Не работает

//    $sss = mysqli_fetch_array($query1);
//
//    foreach ($sss as $val){
//        echo $val['name'];
//    }

    //Работает
    while($row=mysqli_fetch_array($query1))
    {
        echo $row['name'],' ', "<br />";
    }

}













//sssssssssssssssssssssssssssssssssssss


$link = mysqli_connect('localhost', 'akame320_mito', 'hidizo33', 'akame320_mito');

$a = 'utf8';

mysqli_set_charset($link, $a);

if ($link == false) {
    print("Ошибка: Невозможно подключиться к MySQL " . mysqli_connect_error());
} else {
    print("Соединение установлено успешно");
}


$link = mysqli_connect('localhost', 'akame320_mito', 'hidizo33', 'akame320_mito');

$sql = 'DELETE INTO cites SET name = "Ярославль"';

$result = mysqli_query($link, $sql);

if ($result == false) {

    print("Произошла ошибка при выполнении запроса");

}





